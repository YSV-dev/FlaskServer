create definer = root@localhost trigger users_trg
    before insert
    on users
    for each row
BEGIN
INSERT INTO referral_seq SET id = DEFAULT;
    SET NEW.referral_code = LAST_INSERT_ID();
    SET NEW.user_uuid = UUID_TO_BIN(UUID());
END;

